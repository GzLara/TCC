from django.contrib import admin
from django.contrib import admin
from .models import *

admin.site.register(TipoSensor)
admin.site.register(Controlador)
admin.site.register(Sensor)
admin.site.register(Regra)
admin.site.register(Leitura)
admin.site.register(Cadastro)
